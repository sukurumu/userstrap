How to have the correct library installed

Open command prompt by going to Search Tab and typing "cmd"
Type "pip install requests" and hit enter
Type "pip install colorama" and hit enter
Then just close the command prompt


** remember you need python installed for this

----------------------------------------------------------------
usernames : use "https://www.random.org/strings/" to generate a string of 4-5 letter users
- use : 
- Each string should be unique (like raffle tickets)
- Numeric digits (0-9)
 Uppercase letters (A-Z)
 Lowercase letters (a-z)

replace the orignal users and click "crtl+s" to save